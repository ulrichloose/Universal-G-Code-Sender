Run the stand-alone distribution from the command line using:
    java -jar -Xmx256m UniversalGcodeSender.jar
